# MaxDrive — Design Spec (excerpt)
Brand tokens: Name: MaxDrive, Logo glyph: MD, Fonts: Inter, Colors: Indigo/Teal.
Layout: left-nav, center grid/list, right details. Components: upload, share modal, previews.
